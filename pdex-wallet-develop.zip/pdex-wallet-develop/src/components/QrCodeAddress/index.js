export { default } from './QrCodeAddress';

export { default as QrCodeAddressDefault } from './QrCodeAddress.default';
