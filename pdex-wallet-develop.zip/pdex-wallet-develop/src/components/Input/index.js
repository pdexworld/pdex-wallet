export {default as TextInput} from './input.text';
export {default as TextInputMaxAmount} from './input.maxAmount';
