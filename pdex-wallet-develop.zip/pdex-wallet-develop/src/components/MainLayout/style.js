import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  content: {
    paddingTop: 42,
  },
  noPaddingStyle: {
    marginHorizontal: -25,
  },
  paddingHeader: {
    marginHorizontal: 25,
  },
});
