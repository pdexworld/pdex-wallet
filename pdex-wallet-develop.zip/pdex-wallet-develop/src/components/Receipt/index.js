export { default } from './Receipt';
