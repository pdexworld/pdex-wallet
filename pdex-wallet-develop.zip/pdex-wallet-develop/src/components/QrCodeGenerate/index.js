import QrCodeGenerate from './QrCodeGenerate';

export default QrCodeGenerate;