import PureModal from './PureModal';

export default PureModal;
