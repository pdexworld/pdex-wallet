import BottomMenu from './BottomMenu';

export default BottomMenu;
