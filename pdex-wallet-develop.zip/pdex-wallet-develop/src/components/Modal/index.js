import Modal from './modal';

export * from './modal.selector';

export * from './modal.actions';

export {default as modalReducer} from './modal.reducer';

export default Modal;
