export const ACTION_TOGGLE_MODAL = '[modal] ButtonGroup modal';
export const ACTION_TOGGLE_LOADING_MODAL = '[modal] ButtonGroup loading modal';
