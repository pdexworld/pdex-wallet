import DeviceLog from './DeviceLog';

export default DeviceLog;