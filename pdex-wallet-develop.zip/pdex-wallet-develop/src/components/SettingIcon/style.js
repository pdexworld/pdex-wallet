import {StyleSheet} from 'react-native';

const style = StyleSheet.create({
  setting: {
    width: 38,
    height: 38,
    marginTop: 'auto',
    marginBottom: 'auto',
  },
});

export default style;
