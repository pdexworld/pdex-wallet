import withLayout from './Layout.enhance';

export { default as withLayout_2 } from './Layout_2.enhance';

export default withLayout;
