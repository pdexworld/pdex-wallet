export { default } from './template';
