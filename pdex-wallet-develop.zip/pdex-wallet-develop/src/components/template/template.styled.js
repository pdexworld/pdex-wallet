import {StyleSheet} from 'react-native';

export const styled = StyleSheet.create({
  container: {},
});
