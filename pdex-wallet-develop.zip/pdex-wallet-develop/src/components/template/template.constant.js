export const ACTION_FETCHING = '[template] Fetching data';
export const ACTION_FETCHED = '[template] Fetched data';
export const ACTION_FETCH_FAIL = '[template] Fetch fail data';
