import { StyleSheet } from 'react-native';
import {COLORS} from '@src/styles';

const style = StyleSheet.create({
  networkName: {
    color: COLORS.lightGrey2,
  },
});

export default style;
