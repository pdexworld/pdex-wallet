import React from 'react';
import { View as RNComponent } from 'react-native';

const View = (props) => <RNComponent {...props} />;

export default View;