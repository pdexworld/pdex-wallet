import { SafeAreaView as RNComponent } from 'react-native';

const SafeAreaView = RNComponent;

export default SafeAreaView;