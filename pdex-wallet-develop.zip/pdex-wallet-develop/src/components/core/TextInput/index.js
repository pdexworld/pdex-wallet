export { default } from './Component';
export { default as InputExtension } from './InputExtension';
export { default as style } from './style';
