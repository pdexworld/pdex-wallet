import Icon from 'react-native-vector-icons/MaterialIcons';

export default Icon;
