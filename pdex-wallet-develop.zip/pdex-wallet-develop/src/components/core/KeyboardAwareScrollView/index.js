export { default } from './KeyboardAwareScrollView';
