import React from 'react';
import { Switch as RNComponent } from 'react-native';

const Switch = (props) => <RNComponent {...props} />;

export default Switch;