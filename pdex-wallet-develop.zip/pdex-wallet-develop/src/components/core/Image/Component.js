import React from 'react';
import { Image as RNComponent } from 'react-native';

const Image = (props) => <RNComponent {...props} />;

export default Image;