import { Picker as RNPicker } from 'react-native';

const Picker = RNPicker;

export default Picker;