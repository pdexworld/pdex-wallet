import { Alert as RNComponent } from 'react-native';

const Alert = RNComponent;

export default Alert;