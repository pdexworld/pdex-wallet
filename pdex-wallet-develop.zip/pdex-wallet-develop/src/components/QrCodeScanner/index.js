import QrCodeScanner, { closeQrScanner, openQrScanner } from './QrCodeScanner';

export default QrCodeScanner;
export { openQrScanner, closeQrScanner };
