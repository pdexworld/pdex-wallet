export default ({
  withdrawing:          'Withdrawing all rewards...',
  withdraw_all:         'Withdraw all rewards',
  get_node_device:      'Get a Node Device',
  remove_from_display:  'Remove from display',
  remove:               'Remove',
  cancel:               'Cancel',
  add_node_again:       'Are you sure?\nYou can add this Node again later.'
});