const BLOCK_TIME = 40; // seconds

export default {
  BLOCK_TIME,
};
